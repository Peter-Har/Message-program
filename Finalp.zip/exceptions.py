# Peter Hartmeier
# phartmei@uci.edu
# 61283483

class Conversation_Sort(Exception):
    pass

class DSU_Join_Issue(Exception):
    pass


